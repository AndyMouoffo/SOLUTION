export default function FormControl({
  id,
  label,
  type,
  placeholder,
  required = true,
  onChange,
}) {
  return (
    <div className="form-control w-full">
      <label htmlFor={id} className="label">
        {label}
      </label>
      <input
        type={type}
        placeholder={placeholder}
        className="input input-bordered w-full"
        id={id}
        onChange={onChange}
        required={required}
        autoComplete="on"
      />
    </div>
  );
}
