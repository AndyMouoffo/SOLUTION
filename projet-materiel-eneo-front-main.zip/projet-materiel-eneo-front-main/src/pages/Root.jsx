import { Outlet } from "react-router-dom";
import Navbar from "../components/Navbar";
import { useUser } from "../hooks/useUser";
import { Navigate } from "react-router-dom";
import { routes } from "../globals/routes";
import { createContext, useState } from "react";
import { useLocalStorage } from "../hooks/useLocalStorage";

export const SearchContext = createContext(null);
export const CartContext = createContext(null);

export default function Root() {
  const [user, setUser] = useUser();
  const [searchToken, setSearchToken] = useState("");
  const [cart, setCart] = useLocalStorage("cart", []);

  if (!user) {
    return <Navigate to={routes.LOGIN} replace />;
  }

  return (
    <CartContext.Provider value={[cart, setCart]}>
      <SearchContext.Provider value={[searchToken, setSearchToken]}>
        <header className="w-4/5 mx-auto my-10">
          <Navbar />
        </header>

        <main className="w-4/5 mx-auto">
          <Outlet />
        </main>
      </SearchContext.Provider>
    </CartContext.Provider>
  );
}
