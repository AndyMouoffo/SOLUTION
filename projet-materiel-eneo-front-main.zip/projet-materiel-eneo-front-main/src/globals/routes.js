export const routes = {
  HOME: "/",
  SIGNUP: "/inscription",
  LOGIN: "/connexion",
  EQUIPMENT_INDEX: "/materiel",
  PENDING_REQUESTS: "/demandes",
  VALIDATED_REQUESTS: "/demandes-validees",
};
