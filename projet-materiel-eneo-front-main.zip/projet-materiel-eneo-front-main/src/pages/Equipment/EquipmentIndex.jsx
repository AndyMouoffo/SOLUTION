import { createContext, useContext, useState } from "react";
import EquipmentCard from "../../components/EquipmentCard";
import { useFetch } from "../../hooks/useFetch";
import { SearchContext } from "../Root";

export const RequestContext = createContext(null);

export default function EquipmentIndex() {
  const url = `${import.meta.env.VITE_API_BASE_URL}/equipments`;
  const [searchToken] = useContext(SearchContext);
  const [equipments, loading, error] = useFetch(url);
  const [requestSuccess, setRequestSuccess] = useState(false);
  const [requestError, setRequestError] = useState();

  const filtered =
    (equipments &&
      equipments.filter((equipment) =>
        equipment.name.toLowerCase().includes(searchToken.toLowerCase())
      )) ||
    [];

  const Content = ({ equipments, loading, error }) => {
    if (loading)
      return (
        <span className="loading loading-spinner loading-sm block mx-auto mt-40" />
      );
    if (error) return <p className="mx-auto">{error}</p>;

    if (filtered.length === 0) {
      return <p className="text-center min-h-16 mt-10">Aucun résultat.</p>;
    }

    return (
      <div className="grid place-items-center sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 min-h-[20rem] gap-5 mb-10">
        {filtered.map((equipment) => (
          <EquipmentCard key={equipment.id} equipment={equipment} />
        ))}
      </div>
    );
  };

  return (
    <>
      <h1 className="sr-only">Matériel</h1>

      <RequestContext.Provider
        value={[
          requestSuccess,
          setRequestSuccess,
          requestError,
          setRequestError,
        ]}
      >
        <Content equipments={equipments} loading={loading} error={error} />

        <div className="hidden alert alert-success fixed top-0 left-1/2 -translate-x-1/2 max-w-2xl">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="stroke-current shrink-0 h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
          <span>Votre commande a été effectuée</span>
        </div>
      </RequestContext.Provider>
    </>
  );
}
