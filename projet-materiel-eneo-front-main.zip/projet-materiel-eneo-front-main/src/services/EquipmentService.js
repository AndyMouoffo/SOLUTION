import axios from "axios";

export async function requestEquipment(equipmentId, quantity) {
  const url = `${import.meta.env.VITE_API_BASE_URL}/equipments/request`;

  return await axios.post(
    url,
    {
      equipment_id: equipmentId,
      quantity: quantity,
    },
    { withCredentials: true }
  );
}

export async function requestEquipments(equipments) {
  const url = `${import.meta.env.VITE_API_BASE_URL}/equipments/requestMany`;

  return await axios.post(url, equipments, { withCredentials: true });
}

export async function validateRequest(requestId) {
  const url = `${
    import.meta.env.VITE_API_BASE_URL
  }/requests/validate/${requestId}`;

  return await axios.post(url, {}, { withCredentials: true });
}
