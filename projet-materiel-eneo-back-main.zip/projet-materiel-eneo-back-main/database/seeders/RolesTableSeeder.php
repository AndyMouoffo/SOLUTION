<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use TCG\Voyager\Models\Role;

class RolesTableSeeder extends Seeder
{
    /**
     * Auto generated seed file.
     */
    public function run()
    {
        $role = Role::firstOrNew(['name' => 'admin']);
        if (!$role->exists) {
            $role->fill([
                'display_name' => 'Administrateur',
            ])->save();
        }

        $role = Role::firstOrNew(['name' => 'agent']);
        if (!$role->exists) {
            $role->fill([
                'display_name' => 'Agent Eneo',
            ])->save();
        }

        $role = Role::firstOrNew(['name' => 'validator']);
        if (!$role->exists) {
            $role->fill([
                'display_name' => 'Validateur',
            ])->save();
        }

        $role = Role::firstOrNew(['name' => 'requestor']);
        if (!$role->exists) {
            $role->fill([
                'display_name' => 'Requestor',
            ])->save();
        }

        $role = Role::firstOrNew(['name' => 'stock_manager']);
        if (!$role->exists) {
            $role->fill([
                'display_name' => 'Gestionnaire de stock',
            ])->save();
        }
    }
}
