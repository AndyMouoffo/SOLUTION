import { Navigate, Outlet } from "react-router-dom";
import logo from "../../assets/images/logo.png";
import { routes } from "../../globals/routes";
import { useUser } from "../../hooks/useUser";

export default function AuthRoot() {
  const [user, setUser] = useUser();

  if (user) {
    return <Navigate to={routes.HOME} replace />;
  }

  return (
    <main className="grid place-items-center min-h-screen">
      <img src={logo} alt="Logo de Eneo Cameroun" className="max-w-[15rem]" />

      <div className="card w-3/4 max-w-2xl min-w-[24rem] bg-base-100 md:shadow-xl">
        <Outlet />
      </div>
    </main>
  );
}
