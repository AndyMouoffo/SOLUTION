import {
  createBrowserRouter,
  Navigate,
  RouterProvider,
} from "react-router-dom";
import AuthRoot from "./pages/Auth/AuthRoot";
import Signup from "./pages/Auth/Signup";
import Login from "./pages/Auth/Login";
import EquipmentIndex from "./pages/Equipment/EquipmentIndex";
import Root from "./pages/Root.jsx";
import { routes } from "./globals/routes";
import PendingRequests from "./pages/Request/PendingRequests";
import ValidatedRequests from "./pages/Request/ValidatedRequests";
import Home from "./pages/Home";

const router = createBrowserRouter([
  {
    element: <Root />,
    children: [
      {
        path: routes.HOME,
        element: <Home />,
      },

      {
        path: routes.EQUIPMENT_INDEX,
        element: <EquipmentIndex />,
      },

      {
        path: routes.PENDING_REQUESTS,
        element: <PendingRequests />,
      },

      {
        path: routes.VALIDATED_REQUESTS,
        element: <ValidatedRequests />,
      },
    ],
  },

  {
    element: <AuthRoot />,
    children: [
      {
        path: routes.SIGNUP,
        element: <Signup />,
      },

      {
        path: routes.LOGIN,
        element: <Login />,
      },
    ],
  },
]);

export default function App() {
  return <RouterProvider router={router} />;
}
