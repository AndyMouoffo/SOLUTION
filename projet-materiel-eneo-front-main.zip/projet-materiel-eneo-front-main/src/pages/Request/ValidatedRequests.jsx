import { useFetch } from "../../hooks/useFetch";

export default function ValidatedRequests() {
  const url = `${import.meta.env.VITE_API_BASE_URL}/requests/validated`;
  const [validatedRequests, loading, error] = useFetch(url);

  const Content = ({ requests, loading, error }) => {
    if (loading)
      return (
        <span className="loading loading-spinner loading-sm block mx-auto mt-40" />
      );
    if (error) return <p className="mx-auto">{error}</p>;

    return (
      <div className="grid place-items-center sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 min-h-[20rem] gap-5 mb-10">
        {requests.map((request) => (
          <div key={request.id} className="card bg-base-100 shadow-xl max-w-xs">
            <figure>
              <img src="https://picsum.photos/600/400" alt="Shoes" />
            </figure>
            <div className="card-body">
              <h2 className="card-title text-ellipsis overflow-hidden whitespace-nowrap">
                <span className="font-black text-primary">
                  {request.quantity}
                </span>
                {request.equipment.name}
              </h2>

              <p>{request.user.name}</p>

              <p className="text-slate-500">
                {new Date(request.created_at).toLocaleDateString("fr-FR", {
                  weekday: "long",
                  year: "numeric",
                  month: "short",
                  day: "numeric",
                })}
              </p>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <>
      <h1 className="text-2xl font-semibold mb-16 ml-5">Demandes Validées</h1>

      <Content requests={validatedRequests} loading={loading} error={error} />
    </>
  );
}
