<?php

namespace App\Http\Controllers;

use App\Models\Equipment;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class EquipmentController extends Controller
{
    public function index()
    {
        if (!Auth::user()->hasPermission('read_equipment'))
            return response()->json('', Response::HTTP_NOT_FOUND);

        $equipments = Equipment::all();

        return response()->json($equipments);
    }
}
