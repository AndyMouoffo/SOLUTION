<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use TCG\Voyager\Models\Permission;
use TCG\Voyager\Models\Role;

class PermissionRoleTableSeeder extends Seeder
{
    /**
     * Auto generated seed file.
     *
     * @return void
     */
    public function run()
    {
        $adminRole = Role::where('name', 'admin')->firstOrFail();
        $agentRole = Role::where('name', 'agent')->firstOrFail();
        $validatorRole = Role::where('name', 'validator')->firstOrFail();
        $requestorRole = Role::where('name', 'requestor')->firstOrFail();

        $adminPermissions = Permission::all();
        $agentPermissions = Permission::where('key', 'read_equipment')->orWhere('key', 'add_equipment_request')->get();
        $validatorPermissions = Permission::where('key', 'read_equipment_requests')->orWhere('key', 'edit_equipment_requests')->get();
        $requestorPermissions = Permission::where('key', 'read_equipment_requests')->orWhere('key', 'edit_equipment_requests')->get();


        $adminRole->permissions()->sync(
            $adminPermissions->pluck('id')->all()
        );

        $agentRole->permissions()->sync(
            $agentPermissions->pluck('id')->all()
        );

        $validatorRole->permissions()->sync(
            $validatorPermissions->pluck('id')->all()
        );

        $requestorRole->permissions()->sync(
            $validatorPermissions->pluck('id')->all()
        );
    }
}
