import axios from "axios";

async function fetchToken() {
  return await axios.get(import.meta.env.VITE_CSRF_AUTH_URL, {
    withCredentials: true,
  });
}

export async function login(credentials) {
  await fetchToken();

  const url = `${import.meta.env.VITE_API_BASE_URL}/login`;

  return await axios.post(url, credentials, {
    withCredentials: true,
  });
}

export async function signup(credentials) {
  const url = `${import.meta.env.VITE_API_BASE_URL}/register`;
  return await axios.post(url, credentials, { withCredentials: true });
}

export async function logout() {
  const url = `${import.meta.env.VITE_API_BASE_URL}/logout`;

  return await axios.post(url, {}, { withCredentials: true });
}
