import { useLocalStorage } from "./useLocalStorage";

export function useUser() {
  const [user, setUser] = useLocalStorage("user", null);

  return [user, setUser];
}
