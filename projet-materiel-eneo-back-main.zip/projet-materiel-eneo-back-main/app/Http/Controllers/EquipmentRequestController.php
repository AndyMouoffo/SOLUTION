<?php

namespace App\Http\Controllers;

use App\Models\EquipmentRequest;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class EquipmentRequestController extends Controller
{
    public function store(Request $request)
    {
        if (!Auth::user()->hasPermission('add_equipment_requests')) {
            return response()->json('', Response::HTTP_NOT_FOUND);
        }

        $validator = Validator::make($request->all(), [
            'equipment_id' => ['required', 'integer'],
            'quantity' => ['required', 'integer'],
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], Response::HTTP_BAD_REQUEST);
        }

        Auth::user()->equipmentRequests()->attach($request->equipment_id, ['quantity' => $request->quantity]);

        return response()->noContent();
    }

    public function storeMany(Request $request)
    {
        $state = DB::table('request_states')->where('key', 'pending')->first();

        if (!Auth::user()->hasPermission('add_equipment_requests')) {
            return response()->json('', Response::HTTP_NOT_FOUND);
        }

        foreach ($request->all() as $item) {
            $validator = Validator::make($item, [
                'equipment_id' => ['required', 'integer'],
                'quantity' => ['required', 'integer'],
            ]);

            if ($validator->fails()) {
                return response()->json(['errors' => $validator->errors()], Response::HTTP_BAD_REQUEST);
            }

            Auth::user()->equipmentRequests()->attach($item['equipment_id'], ['quantity' => $item['quantity'], 'request_state_id' => $state->id]);
        }

        return response()->noContent();
    }

    public function getPending()
    {
        if (!Auth::user()->hasPermission('read_equipment_requests')) {
            return response()->json('', Response::HTTP_NOT_FOUND);
        }

        $pendingState = DB::table('request_states')->where('key', 'pending')->first();
        $pendingRequests = EquipmentRequest::with(['user', 'equipment'])->where('request_state_id', $pendingState->id)->get();

        return response()->json($pendingRequests);
    }

    public function validateRequest($id)
    {
        if (!Auth::user()->hasPermission('edit_equipment_requests')) {
            return response()->json('', Response::HTTP_NOT_FOUND);
        }

        $validatedState = DB::table('request_states')->where('key', 'validated')->first();
        $request = EquipmentRequest::find($id);

        $request->update(['request_state_id' => $validatedState->id]);
        $request->save();

        return response()->noContent();
    }

    public function getValidated()
    {
        if (!Auth::user()->hasRole('requestor')) {
            return response()->json('', Response::HTTP_NOT_FOUND);
        }

        $validatedState = DB::table('request_states')->where('key', 'validated')->first();
        $validatedRequests = EquipmentRequest::with(['user', 'equipment'])->where('request_state_id', $validatedState->id)->get();

        return response()->json($validatedRequests);
    }
}
