import { Link, useLocation, useNavigate } from "react-router-dom";
import logo from "./../assets/images/logo.png";
import { useUser } from "../hooks/useUser";
import { logout } from "../services/AuthService";
import { routes } from "../globals/routes";
import { useContext } from "react";
import { CartContext, SearchContext } from "../pages/Root";
import {
  requestEquipment,
  requestEquipments,
} from "../services/EquipmentService";

export default function Navbar() {
  const [user, setUser] = useUser();
  const [searchToken, setSearchToken] = useContext(SearchContext);
  const [cart, setCart] = useContext(CartContext);
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout()
      .then(() => {
        setUser(null);

        setTimeout(() => {
          navigate(routes.LOGIN, { replace: true });
        }, 0);
      })
      .catch(console.error);
  };

  const handleSearchChange = (e) => {
    setSearchToken(e.target.value);
  };

  const handleRequest = () => {
    if (cart.length === 0) return;

    requestEquipments(cart)
      .then(() => {
        setCart([]);
      })
      .catch(console.error);
  };

  return (
    <div className="navbar justify-between bg-base-100 rounded-full shadow-xl py-5 px-10">
      <Link className="normal-case text-xl" to={routes.HOME}>
        <img src={logo} alt="Logo de Eneo Cameroun" className="max-w-[90px]" />
      </Link>

      {location.pathname === routes.EQUIPMENT_INDEX && (
        <div className="hidden lg:join">
          <div>
            <div>
              <input
                type="search"
                name="search"
                className="input input-bordered join-item"
                placeholder="Rechercher un article..."
                onChange={handleSearchChange}
              />
            </div>
          </div>
          <div className="indicator">
            <button className="btn join-item">Rechercher</button>
          </div>
        </div>
      )}

      <div>
        {location.pathname === routes.EQUIPMENT_INDEX && (
          <div className="dropdown dropdown-end">
            <label tabIndex={0} className="btn btn-ghost btn-circle">
              <div className="indicator">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
                  />
                </svg>
                <span className="badge badge-sm indicator-item">
                  {cart.reduce(
                    (total, currentItem) => total + currentItem.quantity,
                    0
                  )}
                </span>
              </div>
            </label>
            <div
              tabIndex={0}
              className="mt-3 z-[1] card card-compact dropdown-content w-52 bg-base-100 shadow"
            >
              <div className="card-body">
                {cart.map((item) => (
                  <div key={item.id} className="bg-slate-200 p-3 rounded-2xl">
                    <p className="text-lg font-semibold">
                      <span className="font-black text-primary">
                        {item.quantity}
                      </span>{" "}
                      {item.name}
                    </p>
                  </div>
                ))}
                <div className="card-actions">
                  <button
                    className="btn btn-primary btn-block"
                    onClick={handleRequest}
                  >
                    Commander
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="dropdown dropdown-end">
          <label tabIndex={0} className="btn btn-ghost btn-circle avatar">
            <div className="w-10 rounded-full">
              <img src="https://i.pravatar.cc/300" />
            </div>
          </label>
          <ul
            tabIndex={0}
            className="menu menu-sm dropdown-content mt-3 z-[1] p-2 shadow bg-base-100 rounded-box w-52"
          >
            <li>
              <a className="justify-between">
                Profile
                <span className="badge">New</span>
              </a>
            </li>
            <li>
              <a>Settings</a>
            </li>
            <li>
              <button onClick={handleLogout}>Déconnexion</button>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
