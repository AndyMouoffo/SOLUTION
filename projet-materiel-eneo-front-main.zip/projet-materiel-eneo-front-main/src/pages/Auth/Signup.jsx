import FormControl from "../../components/FormControl";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { routes } from "../../globals/routes";
import { signup } from "../../services/AuthService";
import { useUser } from "../../hooks/useUser";

const signupFields = [
  {
    id: "name",
    type: "text",
    label: "Nom",
    placeholder: "Nom",
  },

  {
    id: "email",
    type: "email",
    label: "Adresse électronique",
    placeholder: "example@gmail.com",
  },

  {
    id: "password",
    type: "password",
    label: "Mot de passe",
    placeholder: "Mot de passe",
  },

  {
    id: "password_confirmation",
    type: "password",
    label: "Confirmation du mot de passe",
    placeholder: "Confirmation du mot de passe",
  },
];

const defaultValues = signupFields.map((field) => {
  return { [field.id]: "" };
});

export default function Signup() {
  const [formData, setFormData] = useState(defaultValues);
  const [errors, setErrors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useUser();
  const navigate = useNavigate();

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.id]: event.target.value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    signup(formData)
      .then((response) => response.data)
      .then(setUser)
      .then(() => {
        setTimeout(() => {
          navigate(routes.HOME, { replace: true });
        }, 0);
      })
      .catch((e) => {
        const errors = (e.response &&
          e.response.data &&
          e.response.data.errors &&
          Object.values(e.response.data.errors).flat()) || [
          "Une erreur est survenue",
        ];

        setErrors(errors);
      })
      .finally(() => {
        setLoading(false);
      });

    setLoading(true);
    setErrors([]);
  };

  return (
    <form className="card-body" onSubmit={handleSubmit}>
      <h1 className="text-center">Inscription</h1>

      <ul className="list-disc text-red-400 ml-8">
        {errors.map((error, i) => (
          <li key={i}>{error}</li>
        ))}
      </ul>

      {signupFields.map((field) => (
        <FormControl
          key={field.id}
          type={field.type}
          id={field.id}
          label={field.label}
          placeholder={field.placeholder}
          onChange={handleChange}
        />
      ))}

      <button type="submit" className="btn btn-primary mt-10">
        {loading ? (
          <span className="loading loading-spinner loading-sm" />
        ) : (
          "Envoyer"
        )}
      </button>

      <Link
        to={routes.LOGIN}
        className="underline underline-offset-4 text-center mt-5"
      >
        J'ai déjà un compte
      </Link>
    </form>
  );
}
