import { requestEquipment } from "../services/EquipmentService";
import { RequestContext } from "../pages/Equipment/EquipmentIndex";
import { useContext, useEffect } from "react";
import { CartContext } from "../pages/Root";

export default function EquipmentCard({ equipment: { id, name } }) {
  const [cart, setCart] = useContext(CartContext);
  const [requestSuccess, setRequestSuccess, requestError, setRequestError] =
    useContext(RequestContext);

  const handleClick = () => {
    const quantity = parseInt(prompt("Quantité"));

    setCart([...cart, { equipment_id: id, name: name, quantity: quantity }]);
  };

  return (
    <div className="card bg-base-100 shadow-xl max-w-xs">
      <figure>
        <img src="https://picsum.photos/600/400" alt="Shoes" />
      </figure>
      <div className="card-body">
        <h2 className="card-title text-ellipsis overflow-hidden whitespace-nowrap">
          {name}
        </h2>

        <div className="card-actions justify-end">
          <button className="btn btn-primary w-full mt-4" onClick={handleClick}>
            Ajouter au panier
          </button>
        </div>
      </div>
    </div>
  );
}
