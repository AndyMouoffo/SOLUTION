import { Navigate } from "react-router-dom";
import { useUser } from "../hooks/useUser";
import { routes } from "../globals/routes";

export default function Home() {
  const [user] = useUser();

  let destination;

  switch (user.role.name) {
    case "agent":
      destination = routes.EQUIPMENT_INDEX;
      break;
    case "admin":
    case "validator":
      destination = routes.PENDING_REQUESTS;
      break;
    case "requestor":
      destination = routes.VALIDATED_REQUESTS;
      break;
    default:
      destination = routes.LOGIN;
      break;
  }

  return <Navigate to={destination} replace />;
}
