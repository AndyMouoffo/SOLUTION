import FormControl from "../../components/FormControl";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { routes } from "../../globals/routes";
import { login } from "../../services/AuthService";
import { useUser } from "../../hooks/useUser";

const loginFields = [
  {
    id: "email",
    type: "email",
    label: "Email",
    placeholder: "Email",
  },

  {
    id: "password",
    type: "password",
    label: "Mot de passe",
    placeholder: "Mot de passe",
  },
];

const defaultValues = loginFields.map((field) => {
  return { [field.id]: "" };
});

export default function Login() {
  const navigate = useNavigate();
  const [user, setUser] = useUser();
  const [formData, setFormData] = useState(defaultValues);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState([]);

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.id]: event.target.value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    setErrors([]);

    setLoading(true);
    login(formData)
      .then((response) => response.data)
      .then(setUser)
      .then(() => {
        setTimeout(() => {
          navigate(routes.HOME, { replace: true });
        }, 0);
      })
      .catch((e) => {
        const errors = (e.response &&
          e.response.data &&
          e.response.data.errors &&
          Object.values(e.response.data.errors).flat()) || [
          "Une erreur est survenue",
        ];

        setErrors(errors);
      })
      .finally(() => setLoading(false));
  };

  return (
    <form className="card-body" onSubmit={handleSubmit}>
      <h1 className="text-center">Connexion</h1>

      <ul className="list-disc text-red-400 ml-8">
        {errors.map((error, i) => (
          <li key={i}>{error}</li>
        ))}
      </ul>

      {loginFields.map((field) => (
        <FormControl
          key={field.id}
          type={field.type}
          id={field.id}
          label={field.label}
          placeholder={field.placeholder}
          onChange={handleChange}
        />
      ))}

      <button type="submit" className="btn btn-primary mt-10">
        {loading ? (
          <span className="loading loading-spinner loading-sm" />
        ) : (
          "Envoyer"
        )}
      </button>

      <Link
        to={routes.SIGNUP}
        className="underline underline-offset-4 text-center mt-5"
      >
        Je n'ai pas encore de compte
      </Link>
    </form>
  );
}
