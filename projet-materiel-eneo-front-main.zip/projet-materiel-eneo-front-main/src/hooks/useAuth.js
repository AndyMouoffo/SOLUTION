import { useState } from "react";
import { useUser } from "./useUser";

export function useAuth() {
  const user = useUser();

  return user ? true : false;
}
