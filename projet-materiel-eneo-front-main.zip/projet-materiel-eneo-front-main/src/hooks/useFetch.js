import { useEffect, useState } from "react";
import axios from "axios";
import { routes } from "../globals/routes";
import { useNavigate } from "react-router-dom";
import { useUser } from "./useUser";

export function useFetch(url) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const [user, setUser] = useUser();

  useEffect(() => {
    axios
      .get(url, { withCredentials: true })
      .then((response) => response.data)
      .then(setData)
      .catch((e) => {
        if (e.response && e.response.status === 401) {
          setUser(null);
          setTimeout(() => {
            navigate(routes.LOGIN);
          }, 0);

          return;
        }

        if (e.response && e.response.status === 404) {
          navigate(routes.HOME, { replace: true });
          return;
        }

        setError(
          (e.response && e.response.data.errors) || "Une erreur est survenue."
        );
      })
      .finally(() => {
        setLoading(false);
      });

    setLoading(true);
  }, []);

  return [data, loading, error];
}
